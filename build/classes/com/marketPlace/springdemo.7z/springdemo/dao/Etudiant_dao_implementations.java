package com.m2i.springdemo.dao;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.m2i.springdemo.model.Etudiant;




@Repository  //component qui va interragir avec la base de donnée
public class Etudiant_dao_implementations implements Etudiant_dao {

	
	@Autowired
	private SessionFactory sessionFactory;
	
	public void ajoutEtu(Etudiant etudiant1) {
		Session session= sessionFactory.getCurrentSession();
	

		try {
			session.beginTransaction(); //succestion de requette sql avec commit et rollback



			Etudiant etudiant1= new Etudiant1();


			session.saveOrUpdate(etudiant1);

			session.getTransaction().commit();

		}
		catch(Exception e) {
			e.printStackTrace();
		}
		
	}

}
