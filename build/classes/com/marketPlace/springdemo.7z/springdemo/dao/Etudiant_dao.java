package com.m2i.springdemo.dao;

import com.m2i.springdemo.model.Etudiant;

public interface Etudiant_dao {
	public void ajoutEtu(Etudiant etudiant1);
}
